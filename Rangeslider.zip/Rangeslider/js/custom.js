var flagemail = false;
var flagdesignation = false;
var flagFName = false;

$(document).ready(function() { 
	
	/*---- selectplan process ----*/
	$(".insertprice").on("keypress", function() {
		var inputval = $(this).val();
		if( inputval.length >= 3 && inputval === "999"){
			alert("input length has exceed");
			$("#addbtn").prop("disabled",true);
		}
		else{
			$("#addbtn").prop("disabled",false);
		}
	});
	/*---- selectplan process ----*/
	/*---- selectplan process ----*/
	$(".insertprice").on("input", function() {
		var reg = /^[0]+/gi;
		if (this.value.match(reg)) {
			this.value = this.value.replace(reg, '');			
			$(this).siblings(".form-label").addClass("grey");
		}		
		this.value = this.value.replace(/[^0-9]/g, '');
		
	});
	$(".insertprice").on("keyup", function() {
		if (/^0/.test(this.value)) {
		  this.value = this.value.replace(/^0/, "")
		}		
	});	
	$(".insertprice").on("input", function() {
		var inputval = $(this).val();
		if (inputval.length > 0){
			$(".proceed-btn").prop("disabled",false);
		}else{
			$(".proceed-btn").prop("disabled",true);
		}
		
	});  
	/*---- selectplan process ----*/

	/*---- email ----*/
	$("#emailAddr").on("input", function() {
		var email = $(this).val();
		var resultEmail = email.replace(/[^a-zA-Z0-9._@]/g, '');
		$(this).val(resultEmail);
		if (resultEmail == "") {
			$(this).siblings(".invalid-feedback").hide();
			$(this).siblings(".valid-feedback").hide();
		}

	});
	$('#emailAddr').on('keyup input', function(e) {

		var thisValue = $(this).val();
		var eRegex = /[^a-zA-Z0-9._@]/g;
		if (thisValue.match(eRegex)) {
			$(this).siblings(".invalid-feedback").hide();
			$(this).siblings(".valid-feedback").show();
            $(".submitPIN").prop("disabled",false);
			$(this).siblings(".form-label").addClass("grey");
			$(this).siblings(".form-label").removeClass("red");
			flagemail = true;
		} 
		else{
			$(this).siblings(".invalid-feedback").show();
			$(this).siblings(".valid-feedback").hide();
			flagemail = false;
		}
		  if (thisValue.length > 0 && (e.keyCode == 8 || e.keyCode == 46)) {
			$(this).siblings(".invalid-feedback").show();
            $(".submitPIN").prop("disabled",true);
			$(this).siblings(".form-label").addClass("red");
			$(this).siblings(".form-label").removeClass("grey");
			$(this).siblings(".valid-feedback").hide();
			flagemail = false;
		}
		verifydetailValidation();
	});
	
	$('#emailAddr').on('blur', function(e) {

        var thisValue = $(this).val();
       
		var eRegex = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
        if (thisValue.match(eRegex)) {
            $(this).siblings(".invalid-feedback").hide();
            $(".submitPIN").prop("disabled",false);
        }
		else{
			$(this).siblings(".invalid-feedback").show();
            $(".submitPIN").prop("disabled",true);
        }
        if (thisValue.length == 0) {
			$(this).siblings(".invalid-feedback").show();
            $(".submitPIN").prop("disabled",true);

        }
    });
	/*---- email ----*/

	/*---- pincode ----*/
	$("#pincode, #pincode1").on("blur", function() {
		var pinVal = $(this).val();		
		if (pinVal.length == 0 ) {			
			$(this).siblings(".invalid-feedback").show();
		}
		verifydetailValidation();
	});
	$("#pincode, #pincode1").on("input", function() {
		var reg = /^[0]+/gi;
		var pinVal = $(this).val();
		if (this.value.match(reg)) {
			this.value = this.value.replace(reg, '');								
			$(this).siblings(".form-label").addClass("grey");
		}
		this.value = this.value.replace(/[^0-9]/g, '');
	});			
	$("#pincode, #pincode1").on("keyup input", function(event) {
		var pinVal = $(this).val();
		this.value = this.value.replace(/[^0-9]/g, '');
		if (pinVal.length == 6) {
			$(this).siblings(".invalid-feedback").hide();
			$(this).siblings(".valid-feedback").show();
			$(this).siblings(".form-label").removeClass("red");
		}else if (pinVal.length > 0 && pinVal.length < 6  && (event.keyCode == 8 || event.keyCode == 46)) {
			$(this).siblings(".invalid-feedback").show();
			$(this).siblings(".valid-feedback").hide();
			$(this).siblings(".form-label").addClass("red");
		}
		else if (pinVal.length == 0) {
			$(this).siblings(".invalid-feedback").hide();
			$(this).siblings(".required_sign").show();
			$(this).siblings(".valid-feedback").hide();
			$(this).siblings(".form-label").removeClass("red");
		}	
		verifydetailValidation();	
	});
	/*---- pincode ----*/

	/*---- mobile ----*/
	$("#mobile").on("input", function() {
		var reg = /^[01234]+/gi;
		if (this.value.match(reg)) {
			this.value = this.value.replace(reg, '');
		}
		this.value = this.value.replace(/[^0-9]/g, '');
	});			
	$("#mobile").on("keyup input", function(event) {

		var tempVal = $(this).val();
		this.value = this.value.replace(/[^0-9]/g, '');
		if (tempVal.length == 10) {
			$(this).siblings(".invalid-feedback").hide();
			$(this).siblings(".valid-feedback").show();
			
			// $(this).siblings(".form-label").addClass("grey");
			$(this).siblings(".form-label").removeClass("red");
		} else if (tempVal.length > 0 && tempVal.length < 10 && (event.keyCode == 8 || event.keyCode == 46)) {
			$(this).siblings(".invalid-feedback").show();
			$(this).siblings(".clearAll").show();
			$(this).siblings(".valid-feedback").hide();				
			$(this).siblings(".form-label").addClass("red");
		}
		if (tempVal.length == 0) {
			$(this).siblings(".invalid-feedback").hide();					
			$(this).siblings(".valid-feedback").hide();		
			$(this).parent().removeClass("invalidBorder validBorder");					
			$(this).siblings(".form-label").removeClass("red");
		}
		verifydetailValidation();

	});
	$("#mobile").on("blur", function() {
		var tempVal = $(this).val();		
		if (tempVal.length == 0 ) {			
			$(this).siblings(".invalid-feedback").show();
		}
		verifydetailValidation();
	});

	/*---- mobile ----*/


	/*---- otp ----*/
	$("#otp").on("input", function() {
		var reg = /^[0]+/gi;
		if (this.value.match(reg)) {
			this.value = this.value.replace(reg, '');
			
		}
		this.value = this.value.replace(/[^0-9]/g, '');
	});
	$("#otp").on("keyup input", function(event) {
		var otpVal = $(this).val();
		this.value = this.value.replace(/[^0-9]/g, '');
		if (otpVal.length == 4) {
			$(this).siblings(".invalid-feedback").hide();
			$(this).siblings(".valid-feedback").show();			
			$(this).siblings(".form-label").css("color", "#82838e");
			$("#verifyOTP").addClass("activeSubmitButton");
			$(".submitOTP").prop("disabled",false);
			$(".otp_query").css("visibility","hidden");
		}else if (otpVal.length > 0 && otpVal.length < 4  && (event.keyCode == 8 || event.keyCode == 46)) {
			$(this).siblings(".invalid-feedback").show();
			$(this).siblings(".otp_action").hide();
			$(this).siblings(".valid-feedback").hide();
			$(".otp_query").css("visibility","visible");
			$(this).siblings(".form-label").css("color", "#b30e0e");
			$("#verifyOTP").removeClass("activeSubmitButton");
			$(".submitOTP").prop("disabled",true);
		}else if (otpVal.length == 0) {
			$(this).siblings(".invalid-feedback").hide();
			$(".otp_query").css("visibility","visible");
			$(this).parent().removeClass("invalidBorder validBorder");
			$(this).siblings(".required_sign").show();
			(this).siblings(".valid-feedback").hide();
			$("#verifyOTP").removeClass("activeSubmitButton");
			$(".submitOTP").prop("disabled",true);
		}
		
	});
	$("#otp").on("focusout", function() {
		var otpVal = $(this).val();
		if (otpVal.length == 0) {
			$(this).siblings(".invalid-feedback").show();
			$(".otp_query").css("visibility","hidden");
		}
	});
	/*---- otp ----*/


	

	$(".form-control").focus(function() {
		$(this).siblings(".form-label").removeClass("placeholderView");
	});
	$(".form-control").on("blur", function(event) {
		if (this.value.length == 0) {
			$(this).siblings(".form-label").addClass("placeholderView");
		}
	});
	$(".form-control").focusout(function() {
		if (this.value.length == 0) {
			$(this).siblings(".invalid-feedback").show();
			$(this).siblings(".form-label").css("color","#82838e");
		}
	});

});

/*---- personaldetail ----*/

$('#enterFullname').on('keyup input', function(e) {
	var tempVal = $(this).val(); 
	
	tempVal = this.value.replace(/[^a-zA-Z ]+/g, "");
	var trimmedValue = tempVal.trim();
	var splittedName = trimmedValue.split(" ");
	var _this = $(this);
	if (e.keyCode === 32 || e.keyCode === 8) {
		$(this).siblings(".invalid-feedback").hide();
		$(".submitDetails").prop("disabled",true);
	}
	if (
		trimmedValue.length > 0 &&
		splittedName.length < 2 &&
		tempVal != ""
	) {
		$(this).siblings(".invalid-feedback").css('background','red');
		$(".submitDetails").prop("disabled",true);
	}else{
		$(this).siblings(".invalid-feedback").hide();
		flagFName = true;
	}
	if(tempVal.length==0){
		$(".submitDetails").prop("disabled",true);
	}
	personaldetailValidation();
	
});
// $('#enterFullName').on('blur', function(e) {
// 	var thisValue = $(this).val(); 
// 	thisValue = this.value.replace(/[^a-zA-Z ]+/g, "");
// 	var trimmedValue = thisValue.trim();
// 	var splittedName = trimmedValue.split(" ");
// 	var _this = $(this);	
// 	if (
// 		trimmedValue.length > 0 &&
// 		splittedName.length < 2 &&
// 		thisValue != ""
// 	) {
// 		$(this).siblings(".invalid-feedback").show();
// 		flagFName = false;
// 	}else{
// 		$(this).siblings(".invalid-feedback").hide();
// 		flagFName = true;
// 	}
// 	if(thisValue.length == 0 ) {
// 		$(this).siblings(".invalid-feedback").show();
// 		flagFName=false;
// 	}
// 	personaldetailValidation();
	
// });
// $("#enterFullname").on("keypress input", function() {
// 	var tempVal = $(this).val();
// 	// alert("ghghhgf"+tempVal);
// 	if (tempVal.length == 1 && tempVal == " ")
// 		this.value = this.value.replace(/ /g, "");

// 	this.value = this.value.replace(/[^a-zA-Z ]+/g, "");
// });
$("#companyName").on("input", function(e) {
	
	var thisValue = $(this).val();
	var resultText = thisValue.replace(/[^a-zA-Z.]/g, '');
        $(this).val(resultText);
		if (thisValue.match(eRegex)) {
			$(this).siblings(".invalid-feedback").hide();
			$(".submitDetails").prop("disabled",false);			
		}		
		else  {
			$(this).siblings(".invalid-feedback").show();
			$(".submitDetails").prop("disabled",true);
		}
		personaldetailValidation();
		
		
});
$('#companyName').on('keyup input', function(e) {
	var inputText = $(this).val();
	if (inputText.length > 0 && (e.keyCode == 8 || e.keyCode == 46)) {
		$(this).siblings(".invalid-feedback").show();
		$(".submitDetails").prop("disabled",true);	
	}
	else{
		$(this).siblings(".invalid-feedback").hide();
		$(".submitDetails").prop("disabled",false);
	}
	personaldetailValidation();
});
$('#companyName').on('blur', function(e) {
	var thisValue = $(this).val(); 
	if(thisValue.length == 0 ) {
			$(this).siblings(".invalid-feedback").show();
			$(".submitDetails").prop("disabled",true);
		}
		else{
			$(this).siblings(".invalid-feedback").hide();
			$(".submitDetails").prop("disabled",false);
			
	}
	personaldetailValidation();
	
});
/*---- personaldetail ----*/

/*---- addressdetail ----*/
$('#enterFlat').on('keyup input', function(e) {
	var inputText = $(this).val();
	if (inputText.length > 0 && (e.keyCode == 8 || e.keyCode == 46)) {
		$(this).siblings(".invalid-feedback").show();
		$(".submitDetails").prop("disabled",true);	
	}
	else{
		$(this).siblings(".invalid-feedback").hide();
		$(".submitDetails").prop("disabled",false);
		addressValidation();

	}	
});
$('#enterStreet').on('keyup input', function(e) {
	var inputText = $(this).val();
	if (inputText.length > 0 && (e.keyCode == 8 || e.keyCode == 46)) {
		$(this).siblings(".invalid-feedback").show();
		$(".submitDetails").prop("disabled",true);	
	}
	else{
		$(this).siblings(".invalid-feedback").hide();
		$(".submitDetails").prop("disabled",false);
		addressValidation();

	}
});
/*---- addressdetail ----*/

/*---- pincode ----*/
$("#pincode1").on("blur", function() {
	var pinVal = $(this).val();		
	if (pinVal.length == 0 ) {			
		$(this).siblings(".invalid-feedback").show();
	}
	addressValidation();
});
$("#pincode1").on("input", function() {
	var reg = /^[0]+/gi;
	var pinVal = $(this).val();
	if (this.value.match(reg)) {
		this.value = this.value.replace(reg, '');								
		$(this).siblings(".form-label").addClass("grey");
	}
	this.value = this.value.replace(/[^0-9]/g, '');
});			
$("#pincode1").on("keyup input", function(event) {
	var pinVal = $(this).val();
	this.value = this.value.replace(/[^0-9]/g, '');
	if (pinVal.length == 6) {
		$(this).siblings(".invalid-feedback").hide();
		$(this).siblings(".valid-feedback").show();
		$(this).siblings(".form-label").removeClass("red");
	}else if (pinVal.length > 0 && pinVal.length < 6  && (event.keyCode == 8 || event.keyCode == 46)) {
		$(this).siblings(".invalid-feedback").show();
		$(this).siblings(".valid-feedback").hide();
		$(this).siblings(".form-label").addClass("red");
	}
	else if (pinVal.length == 0) {
		$(this).siblings(".invalid-feedback").hide();
		$(this).siblings(".required_sign").show();
		$(this).siblings(".valid-feedback").hide();
		$(this).siblings(".form-label").removeClass("red");
	}	
	addressValidation();	
});
/*---- pincode ----*/

$(".submitPIN").click(function() {
	$(".progress_step2").addClass("d-block");
	$(".progress_step1").addClass("d-none");
	$(".progress_step1").removeClass('d-block');
});
$(".submitOTP").click(function() {
	$(".progress_step1").addClass("d-none");
	$(".progress_step2").addClass("d-none").removeClass('d-block');
	$(".progress_step3").addClass("d-block").removeClass('d-none');
	$(".progress_bar_steps #step1").removeClass('active');
	$(".progress_bar_steps #step2").removeClass('active');
	$(".progress_bar_steps #step3").addClass("active");
});
$(".submitDetails").click(function() {
	$(".progress_step1").addClass("d-none");
	$(".progress_step2").addClass("d-none").removeClass('d-block');
	$(".progress_step3").addClass("d-none").removeClass('d-block');
	$(".progress_step4").addClass("d-block").removeClass('d-none');
});

$("#proceed-selection, #enterdetail").click(function() {
	$(".plan_wrapper_background").addClass("d-none");
	$(".progress_step1").addClass("d-block");
	$(".progress_bar_steps #step1").removeClass('active');
	$(".progress_bar_steps #step2").addClass("active");
});
/*---- Otp Countdown ----*/
var timer2 = "2:31";
var interval = setInterval(function() {	
	var timer = timer2.split(':');
	var minutes = parseInt(timer[0], 10);
	var seconds = parseInt(timer[1], 10);
	--seconds;
	minutes = (seconds < 0) ? --minutes : minutes;
	if (minutes < 0) clearInterval(interval);
	seconds = (seconds < 0) ? 60 : seconds;
	seconds = (seconds < 10) ? '0' + seconds : seconds;
	$('#Otpresend, #otpTime').html(minutes + ':' + seconds);
	timer2 = minutes + ':' + seconds;
}, 1000);
/*---- Otp Countdown ----*/


/*---- form validation ----*/
function verifydetailValidation(){

	if((flagemail == true) && ($("#pincode").val().length > 0) && ($("#mobile").val().length == 10) && ($("#emailAddr").val().length > 0)){
			$(".submitPIN").prop("disabled",false);
	 }else{
		 $(".submitPIN").prop("disabled",true);
	 }
	
}
/*---- form validation ----*/
/*---- form validation ----*/
function personaldetailValidation(){

	if((flagFName==true) && ($("#enterFullName").val().length > 0) && ($("#companyName").val().length > 0)){
			$(".submitDetails").prop("disabled",false);
	 }else{
		 $(".submitDetails").prop("disabled",true);
	 }
	
}
/*---- form validation ----*/
/*---- form validation ----*/
function addressValidation(){

	if((flagemail == true) && ($("#pincode1").val().length > 0) && ($("#enterFlat").val().length > 0) && ($("#enterStreet").val().length > 0)){
		$(".submitForm").prop("disabled",false);
	}else{
		$(".submitForm").prop("disabled",true);
	}
	
}
/*---- esim form validation ----*/

$("#esim").on("blur", function() {
	var pinVal = $(this).val();		
	if (pinVal.length == 0 ) {			
		$(this).siblings(".invalid-feedback").show();
	}
	verifydetailValidation();
});
$("#esim").on("input", function() {
	
	var pinVal = $(this).val();
	if (this.value.match(reg)) {
		this.value = this.value.replace(reg, '');								
		$(this).siblings(".form-label").addClass("grey");
	}
	
});			
$("#esim").on("keyup input", function(event) {
	var pinVal = $(this).val();
	if (pinVal.length == 3) {
		$(this).siblings(".invalid-feedback").hide();
		$(this).siblings(".valid-feedback").show();
		$(this).siblings(".form-label").removeClass("red");
	}else if (pinVal.length > 0 && pinVal.length < 6  && (event.keyCode == 8 || event.keyCode == 46)) {
		$(this).siblings(".invalid-feedback").show();
		$(this).siblings(".valid-feedback").hide();
		$(this).siblings(".form-label").addClass("red");
	}
	else if (pinVal.length == 0) {
		$(this).siblings(".invalid-feedback").hide();
		$(this).siblings(".required_sign").show();
		$(this).siblings(".valid-feedback").hide();
		$(this).siblings(".form-label").removeClass("red");
	}	
	verifydetailValidation();	
});

	/*---- esim ----*/


function updateTextInput(val) {
	document.getElementById('esim').value=val; 
}

function updateRange(val){
	document.getElementById('rangesli').value=val;
}

if(('#esim').lenght != ''){
	$('#esimplaceholder').removeClass('placeholderView');
}
else{
	
}
	