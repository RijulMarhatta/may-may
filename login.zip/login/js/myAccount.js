$(document).ready(function () {
  // $(".abc").on("input", function() {
  //     var specials=/[<>%]/;
  //     var abc = $(".abc").val();
  //     if (specials.test(abc)) {
  //         this.value = this.value.replace(specials, '');
  //     }
  // });

  // $(".backgroundImg img").attr("src", "images/mainImg.png");
  // $("#primaryCustomer .close img, #corporateAccount .close img").attr("src", "images/cross.png");

  $("#mobile").on("input", function () {
    var reg = /^[0-4]+/gi;
    if (this.value.match(reg)) {
      this.value = this.value.replace(reg, "");
    }
    this.value = this.value.replace(/[^0-9]/g, "");
  });
  $("#mobile").on("keyup input", function (event) {
    var tempVal = $(this).val();
    if (tempVal.length == 10) {
      $(this).siblings(".invalid-feedback").hide();
      $(this).parent().addClass("validBorder");
      $(this).parent().removeClass("invalidBorder");
      $(this).siblings(".clearAll").show();
      $(".sendotpBtn").prop("disabled", false);
    } else if (
      tempVal.length > 0 &&
      tempVal.length < 10 &&
      (event.keyCode == 8 || event.keyCode == 46)
    ) {
      $(this).siblings(".invalid-feedback").show();
      $(this).parent().addClass("invalidBorder");
      $(this).parent().removeClass("validBorder");
      $(this).siblings(".clearAll").show();
      $(".sendotpBtn").prop("disabled", true);
    } else if (
      (tempVal.length > 0 &&
        tempVal.length < 10 &&
        event.keyCode >= 48 &&
        event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105)
    ) {
      $(this).parent().addClass("validBorder");
      $(this).parent().removeClass("invalidBorder");
      $(this).siblings(".invalid-feedback").hide();
      $(".sendotpBtn").prop("disabled", true);
      $(this).siblings(".clearAll").show();
    }
    if (tempVal.length == 0) {
      $(this).siblings(".invalid-feedback").hide();
      $(this).parent().removeClass("invalidBorder validBorder");
      $(".sendotpBtn").prop("disabled", true);
      $(this).siblings(".clearAll").hide();
    }

    if (
      (tempVal.length >= 1 && event.keyCode >= 48 && event.keyCode <= 57) ||
      (event.keyCode >= 96 && event.keyCode <= 105)
    ) {
      $("#mobile").siblings(".clearAll").show();
    }

    if (event.keyCode == 86 && event.keyCode == 17) {
      $("#mobile").siblings(".clearAll").show();
    }
  });

  $("#mobile").on("input", function () {
    var reg = /^0+/gi;
    if (this.value.match(reg)) {
      this.value = this.value.replace(reg, "");
    }
  });

  // if ($(window).width() <= 1024) {
  //     $(".backgroundImg img").attr("src", "images/mainTabletImg.png");
  // }

  // if ($(window).width() < 768) {
  //     $(".backgroundImg img").attr("src", "images/mainMobileImg.png");
  // }

  $(".enterMobileSection").focusout(function (event) {
    var $this = $("#mobile");
    if ($this.val().length < 10 && $this.val().length > 0) {
      $this.siblings(".invalid-feedback").show();
      $this.parent().addClass("invalidBorder");
      $this.parent().removeClass("validBorder");
      $this.siblings(".clearAll").show();
    }
  });

  $(".clearAll").on("mousedown touchstart", function (event) {
    $(this).hide();
    $("#mobile").val(null);
    $(this).parent().removeClass("invalidBorder");
    $(this).siblings(".invalid-feedback").hide();
    $(".sendotpBtn").prop("disabled", true);
    $("#mobile").focus();
    $(this).siblings(".bootLabel").hide();
  });

  /* not a primary customer popup starts */
  if (screen.width < 767) {
    $("#primaryCustomer .modal-dialog").removeClass("modal-dialog-centered");
    $("#primaryCustomer").addClass("fade");
    $("#primaryCustomer .close img").attr("src", "images/mobileCross.png");
    document.addEventListener("swiped-down", function (e) {
      if ($("#primaryCustomer").hasClass("show")) {
        $("#primaryCustomer").modal("hide");
      }
    });
  }
  /* not a primary customer popup ends */

  /* corporate account popup starts */
  if (screen.width < 767) {
    $("#corporateAccount .modal-dialog").removeClass("modal-dialog-centered");
    $("#corporateAccount").addClass("fade");
    $("#corporateAccount .close img").attr("src", "images/mobileCross.png");
    document.addEventListener("swiped-down", function (e) {
      if ($("#corporateAccount").hasClass("show")) {
        $("#corporateAccount").modal("hide");
      }
    });
  }

  placeholderLabel();
});

function placeholderLabel() {
  $(".bootLabel").hide();
  var ua = window.navigator.userAgent;
  var msie = ua.indexOf("MSIE ");

  if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
    // If Internet Explorer, return version number
    $(".form-control").focus(function (event) {
      $(this).siblings(".bootLabel").show();
    });
    $(".form-control").on("blur", function (event) {
      if (this.value.length == 0) {
        $(this).siblings(".bootLabel").hide();
      }
    });
  } // If another browser, return 0
  else {
    $(".form-control").on("keyup input", function (event) {
      $(this).siblings(".bootLabel").show();
      var tempVal = $(this).val();
      if (tempVal.length <= 0) {
        $(this).siblings(".bootLabel").hide();
      }
    });
  }

  return false;
}
