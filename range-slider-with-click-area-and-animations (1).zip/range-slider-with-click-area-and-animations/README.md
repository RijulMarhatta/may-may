# Range slider with click area and animations

A Pen created on CodePen.io. Original URL: [https://codepen.io/tgallimore/pen/owqJaR](https://codepen.io/tgallimore/pen/owqJaR).

Using &lt;div> elements to imitate an input range slider. This is because of the very specific requirement around how it works. (Mainly, there needs to be a click area around the sliders. But also the animation, jumping to position on mouse etc are required).